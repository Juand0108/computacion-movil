-- phpMyAdmin SQL Dump
-- version 4.6.4
-- https://www.phpmyadmin.net/
--
-- Servidor: localhost
-- Tiempo de generación: 18-12-2024 a las 03:53:41
-- Versión del servidor: 5.7.15-log
-- Versión de PHP: 5.6.26

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `ventas_servicios`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `servicios`
--

CREATE TABLE `servicios` (
  `id` int(11) NOT NULL,
  `nombre` varchar(100) NOT NULL,
  `precio` decimal(10,2) NOT NULL,
  `detalles` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `servicios`
--

INSERT INTO `servicios` (`id`, `nombre`, `precio`, `detalles`) VALUES
(1, 'Internet Satelital - 1 Hora', '5.00', 'Acceso a internet satelital por una hora.'),
(2, 'Recarga Telefónica - 5 USD', '5.00', 'Recarga de saldo telefónico por valor de $5 USD.'),
(3, 'Recarga Telefónica - 10 USD', '10.00', 'Recarga de saldo telefónico por valor de $10 USD.'),
(4, 'Internet Satelital - 5 Horas', '20.00', 'Acceso a internet satelital por cinco horas.');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuarios`
--

CREATE TABLE `usuarios` (
  `id` int(11) NOT NULL,
  `correo` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `rol` enum('vendedor','dueno') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `usuarios`
--

INSERT INTO `usuarios` (`id`, `correo`, `password`, `rol`) VALUES
(1, 'vendedor@correo.com', '827ccb0eea8a706c4c34a16891f84e7b', 'vendedor'),
(2, 'dueno@correo.com', '827ccb0eea8a706c4c34a16891f84e7b', 'dueno');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `ventas`
--

CREATE TABLE `ventas` (
  `id` int(11) NOT NULL,
  `vendedor` varchar(100) NOT NULL,
  `cliente` varchar(100) NOT NULL,
  `servicio_id` int(11) NOT NULL,
  `duracion` decimal(10,2) NOT NULL,
  `precio` decimal(10,2) NOT NULL,
  `total` decimal(10,2) NOT NULL,
  `fecha_venta` datetime DEFAULT CURRENT_TIMESTAMP,
  `comprobante` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `ventas`
--

INSERT INTO `ventas` (`id`, `vendedor`, `cliente`, `servicio_id`, `duracion`, `precio`, `total`, `fecha_venta`, `comprobante`) VALUES
(1, 'yo', 'el', 1, '5.00', '5.00', '25.00', '2024-12-16 15:48:33', ''),
(2, 'yos', 'els', 4, '5.00', '20.00', '100.00', '2024-12-16 16:22:30', ''),
(3, 'yos', 'els', 1, '2.00', '5.00', '10.00', '2024-12-16 16:26:54', ''),
(4, 'yo', 'JA', 2, '2.00', '5.00', '10.00', '2024-12-16 16:30:58', ''),
(5, 'yos', 'JA', 2, '23.00', '5.00', '115.00', '2024-12-16 16:45:12', ''),
(6, 'yo', 'JA', 1, '3.00', '5.00', '15.00', '2024-12-16 16:54:34', ''),
(7, 'yo', 'JA', 1, '3.00', '5.00', '15.00', '2024-12-16 16:54:38', ''),
(8, 'yo', 'JA', 1, '2.00', '5.00', '10.00', '2024-12-16 16:55:22', ''),
(9, 'yazs', 'sad', 4, '2.00', '20.00', '40.00', '2024-12-16 18:09:27', ''),
(10, 'yo', 'JA', 2, '21.00', '5.00', '105.00', '2024-12-16 18:16:30', ''),
(11, 'yo', 'JA', 1, '1.00', '5.00', '5.00', '2024-12-16 18:24:49', ''),
(12, 'OI', 'NGBIFU5VFI', 1, '30.00', '5.00', '150.00', '2024-12-16 19:36:51', ''),
(13, 'NOM', 'SDFD', 2, '3.00', '5.00', '15.00', '2024-12-16 19:37:10', ''),
(14, 'DAS', 'ASD', 2, '2.00', '5.00', '10.00', '2024-12-16 19:57:16', ''),
(15, 'yo', 'JA', 2, '2.00', '5.00', '10.00', '2024-12-16 23:26:22', ''),
(16, 'yo', 'JA', 1, '2.00', '5.00', '10.00', '2024-12-16 23:43:07', ''),
(17, 'yo', 'JA', 2, '1.00', '5.00', '5.00', '2024-12-16 23:47:48', ''),
(18, 'yo', 'JA', 1, '2.00', '5.00', '10.00', '2024-12-17 11:33:52', 'C:\\AppServ\\www\\Sistema_ventas/comprobantes/6761a7f07985f_cf1bf7a6-1c8f-4645-83a9-85b894fad74c.jpg'),
(19, 'yo', 'JA', 1, '12.00', '5.00', '60.00', '2024-12-17 11:34:33', 'C:\\AppServ\\www\\Sistema_ventas/comprobantes/6761a819b1d94_WhatsApp Image 2024-12-11 at 10.45.58 PM.jpeg'),
(20, 'yo', 'JA', 1, '1.00', '5.00', '5.00', '2024-12-17 11:36:13', 'C:\\AppServ\\www\\Sistema_ventas/comprobantes/6761a87d37055_velocidad.jpg'),
(21, 'yo', 'JA', 1, '3.00', '5.00', '15.00', '2024-12-17 17:50:34', 'C:\\AppServ\\www\\Sistema_ventas/comprobantes/6762003ade748_velocidad.jpg'),
(22, 'yo', 'JA', 1, '2.00', '5.00', '10.00', '2024-12-17 22:45:45', 'C:\\AppServ\\www\\Sistema_ventas/comprobantes/67624569c188c_velocidad.jpg');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `servicios`
--
ALTER TABLE `servicios`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `correo` (`correo`);

--
-- Indices de la tabla `ventas`
--
ALTER TABLE `ventas`
  ADD PRIMARY KEY (`id`),
  ADD KEY `servicio_id` (`servicio_id`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `servicios`
--
ALTER TABLE `servicios`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT de la tabla `ventas`
--
ALTER TABLE `ventas`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;
--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `ventas`
--
ALTER TABLE `ventas`
  ADD CONSTRAINT `ventas_ibfk_1` FOREIGN KEY (`servicio_id`) REFERENCES `servicios` (`id`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
